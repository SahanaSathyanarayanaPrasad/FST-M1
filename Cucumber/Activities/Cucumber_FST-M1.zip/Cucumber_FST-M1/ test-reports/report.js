$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Activity_1.feature");
formatter.feature({
  "line": 2,
  "name": "Basic Syntax",
  "description": "",
  "id": "basic-syntax",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@activity1"
    }
  ]
});
formatter.scenario({
  "line": 4,
  "name": "Opening a webpage using Selenium",
  "description": "",
  "id": "basic-syntax;opening-a-webpage-using-selenium",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "User is on Google Home Page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "User types in Cheese and hits ENTER",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "Show how many search results were shown",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Close the browser",
  "keyword": "And "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
});