package com.java;

public class practice {
	
	public void forloop() {
		
		for(int i=0;i<=10;i++) {
			
			if(i%2 != 0) {
				System.out.println(i);
				
			}
			
		}

	}
	
		
	public void test_1() {
		
		for(int i=0;i<=10;i++) {
			
			
		}
	}


public static void main (String [] args) {
	
	practice p = new practice();
	//p.forloop();
	practice_2 rn=new practice_2();
	rn.reversenum();

}

}
	