package com.java;

import java.util.Scanner;

public class practice_2 {

	public void reversenum () {
		int num = 0;
		int reversenum = 0;
		
		Scanner in = new Scanner(System.in);
		
			
	}
}
